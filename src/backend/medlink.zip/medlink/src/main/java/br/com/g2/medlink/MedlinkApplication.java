package br.com.g2.medlink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedlinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedlinkApplication.class, args);
	}

}
