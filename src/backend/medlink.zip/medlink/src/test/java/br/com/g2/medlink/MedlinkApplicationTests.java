package br.com.g2.medlink;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedlinkApplicationTests {

	@Test
	void contextLoads() {
	}

}
